# ssh_auto

This is a simple ssh automation script
